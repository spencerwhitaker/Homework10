var movement1;
var movement2;
var movement3;
var movement4;
var movement5;
var movement6;
var size1;
var ellipseAx;
var rectAx;
var circleAy;
var ellipseBy;
var circleBx;
var circleBy;
var textAs;

function setup() {
  createCanvas(400, 400);
  movement1 = Math.floor(Math.random() * 10) + 1;
  movement2 = Math.floor(Math.random() * 10) + 1;
  movement3 = Math.floor(Math.random() * 10) + 1;
  movement4 = Math.floor(Math.random() * 10) + 1;
  movement5 = Math.floor(Math.random() * 10) + 1;
  movement6 = Math.floor(Math.random() * 10) + 1;
  textAs = 28
  size1 = -1;
  ellipseAx = 140
  rectAx = 60
  circleAy = 175
  ellipseBy = 200
  circleBx = 260
  circleBy = 175
}

function draw() {
  background(220,220,220);
  fill(255,218,185);
  ellipse(50,200,50,100);
  ellipse(350,ellipseBy,50,100);
  if(ellipseBy >= 360 || ellipseBy <= 40)
    {
       movement4 *= -1;
    }

     ellipseBy += movement4;
  circle(200,200,300);
  fill(255,255,255);
  ellipse(ellipseAx,175,80,60);
    if(ellipseAx >= 360 || ellipseAx <= 40)
    {
       movement1 *= -1;
    }

     ellipseAx += movement1;
  ellipse(260,175,80,60);
  fill(0,100,19);
  circle(140,175,30);
  circle(circleBx,circleBy,30);
  if(circleBx >= 385 || circleBx <= 15)
    {
       movement5 *= -1;
    }

     circleBx += movement5;
  if(circleBy >=385 || circleBy <= 15)
    {
    movement6 *= -1;
    }
    circleBy += movement6;
  fill(0,0,0)
  circle(260,circleAy,10);
  if(circleAy >= 395 || circleAy <= 5)
    {
       movement3 *= -1;
    }

     circleAy += movement3;
  circle(140,175,10);
  fill(255,210,190);
  triangle(175,240,200,165,225,240);
  fill(55,27,7);
  point(100,220);
  point(123,215);
  point(130,240);
  point(142,255);
  point(160,235);
  point(135,224);
  point(275,230);
  point(265,242);
  point(250,230);
  point(247,247);
  point(269,238);
  point(255,215);
  point(239,235);
  fill(255,255,255);
  quad(140,270,260,270,245,300,155,300);
  fill(0,0,0);
  line(148,285,252,285);
  line(200,270,200,300);
  line(175,270,175,300);
  line(225,270,225,300);
  line(152,270,152,293);
  line(248,270,248,293);
  fill(125,0,0);
  rect(100,25,200,50);
  rect(rectAx,60,280,70);
  if(rectAx >= 400 || rectAx <= 0)
    {
       movement2 *= -1;
    }

     rectAx += movement2;
  fill(255,255,255)
  textSize(textAs)
  text('Number 1 Griz Fan',82,105)
  if(textAs == 33 || textAs == 23)
  {
    size1 *=-1
  }
  textAs += size1;
  textSize(16)
  fill(0,0,0)
  text('Spencer Whitaker',250,375)
}